<? //

// array() => empty string

$a = array();
mysql_query($a);






?>
