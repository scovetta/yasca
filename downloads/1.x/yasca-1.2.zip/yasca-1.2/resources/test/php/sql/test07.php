<? //

if ($get) {
    $x = 'a' . 'b';
} else {
    $x = 'c' . 'd';
}
mysql_query($x);






?>
