<? //

// very simple initial test

mysql_query("hi");
mysql_query("SELECT * FROM table WHERE id=7");
mysql_query('SELECT * FROM table WHERE id=7');


?>
