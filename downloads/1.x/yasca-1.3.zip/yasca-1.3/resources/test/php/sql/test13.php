<? //

// do-while: least precision

$sql = 'startx';

do 
{
    $sql .= 'xyz';
} while ($get);

mysql_query($sql);






?>
