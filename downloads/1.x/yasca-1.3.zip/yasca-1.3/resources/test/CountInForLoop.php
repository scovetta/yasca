<?php

    $a = array(1,2,3);

    for ($i=0; $i<count($a); $i++) {
	// do something
    }
?>