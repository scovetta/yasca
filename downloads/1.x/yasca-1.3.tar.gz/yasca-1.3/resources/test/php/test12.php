<?php

// isset; currently stupid, but sound

$x1 = 1;
if (isset($x1)) {
    $x2 = 2;
} else {
    $x2 = 3;
}

~_hotspot0;     // x1:1, x2:T


?>
