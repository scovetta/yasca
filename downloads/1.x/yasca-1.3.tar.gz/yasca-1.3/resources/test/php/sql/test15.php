<? //

// control flow merge

$a = 'x';
if ($get) {
    $a = 'y';
}
mysql_query($a);






?>
