<? //

// method call

$a = $m->blob();
mysql_query($a);






?>
