<? //

// it would be nice if prefix extraction would automatically
// compute the prefix "abc"

foo('abcd');
foo('abcx');
function foo($query) {
    mysql_query($query);
}





?>
