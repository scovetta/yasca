<? //

// unset => empty string

$a = 7;
unset($a);
mysql_query($a);






?>
