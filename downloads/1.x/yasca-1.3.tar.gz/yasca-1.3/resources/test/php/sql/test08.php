<? //

// unmodeled builtin functions

$a = 'x';
$a = trim($a);
mysql_query($a);






?>
