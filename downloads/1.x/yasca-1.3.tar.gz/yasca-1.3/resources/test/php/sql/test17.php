<? //

// canonical cycle example, 2
$a = 'a';
while ($get) {
    $a .= 'b';
} 
mysql_query($a);


// canonical cycle example
$a = 'a';
do {
    $a .= 'b';
} while ($get);
mysql_query($a);







?>
