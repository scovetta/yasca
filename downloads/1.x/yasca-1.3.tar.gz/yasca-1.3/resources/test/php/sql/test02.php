<? //


$a = 'y';
mysql_query('x' . $a . 'z');





?>
