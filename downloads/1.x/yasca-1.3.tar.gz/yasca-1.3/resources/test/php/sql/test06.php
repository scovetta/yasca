<? //

// abbreviated concat

$x = 'a';
$x .= 'b';
mysql_query($x);






?>
