<? //

$a = $_GET['a'];
mysql_query('x' . $a . 'y');





?>
