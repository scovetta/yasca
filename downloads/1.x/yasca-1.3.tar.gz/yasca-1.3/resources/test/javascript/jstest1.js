function test() {
	alert("foo")
    alert("bar");
}
