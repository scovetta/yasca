<?

    print "hello";

?>