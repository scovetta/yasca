#!/bin/sh
./resources/utility/phplint/phplint --modules-path ./resources/utility/phplint/modules $*