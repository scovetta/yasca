
class MethodReturnsConstant {
    private int getFoo() {
	return 3;
    }
}