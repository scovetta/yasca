class A {
    /** User password */
    private String password;

    /**
     * Sets the password.
     */
    public void setPassword(String password) {
	this.password = password;
    }
}