<? //

// basic xss test case


echo $evil;
echo 'harmless';
echo $anotherevil;


?>
