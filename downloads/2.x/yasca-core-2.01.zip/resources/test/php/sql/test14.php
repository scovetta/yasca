<? //

// a graph does not have to be a tree in order to be simple to solve;
// it suffices if it has no loops, such as in this case
// (directed acyclic graph, DAG)

$a = 'z';
$sql = 'x' . $a . 'y' . $a;
mysql_query($sql); 






?>
