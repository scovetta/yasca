<? //


// this was a small bug:
// the prefix should be ' instead of \'

mysql_query('\'');






?>
