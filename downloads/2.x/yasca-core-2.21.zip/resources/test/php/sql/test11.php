<? //

$a = 's' + 't';
mysql_query($a);






?>
