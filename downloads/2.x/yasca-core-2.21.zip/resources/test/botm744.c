
void getFoo() {
	// should get caught
	if (s != foo || s != bar) {
		// blah
	}
    
}