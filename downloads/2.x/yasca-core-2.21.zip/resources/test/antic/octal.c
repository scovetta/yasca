
void foo() {
    printf("\128");
}