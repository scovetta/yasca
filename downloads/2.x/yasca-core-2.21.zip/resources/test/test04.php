<? //

$a = $_GET['a'];
mysql_query("select * from foo where t = '$a'");


?>
