<? //

// sprintf (varargs)


$evil = addslashes($evil);
$a = sprintf('good', $evil, 'good');
mysql_query($a);





?>
