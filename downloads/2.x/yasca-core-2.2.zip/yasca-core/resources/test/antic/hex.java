
public void foo() {
    System.out.println("\uABCDE:");
}