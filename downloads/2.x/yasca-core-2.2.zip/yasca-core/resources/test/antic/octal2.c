
void foo() {
    printf("\1287");
}