
char* getFoo() {
    char foo[10];
    int i=0;
    for (i=0; i<10; i++) {
	// ignore
    }
    return foo;
}