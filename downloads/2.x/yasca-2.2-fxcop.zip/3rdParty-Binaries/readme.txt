FxCop is a tool developed by Microsoft and is not open-source. In order to use FxCop,
you must download the tool directly from Microsoft. We are unable to provide the tool
in a "ready-for-use" form.

You can download FxCop from:
	http://code.msdn.microsoft.com/codeanalysis
