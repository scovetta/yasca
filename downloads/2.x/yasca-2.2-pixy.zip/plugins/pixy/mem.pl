# minimum and maximum memory that you want Pixy to use
$mem_min = '256m';
$mem_max = '1024m';

# - colon (:) for Linux
# - semicolon (;) for Windows
$classpath_separator = ':';
